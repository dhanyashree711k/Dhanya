-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2024 at 05:38 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aradhya`
--

-- --------------------------------------------------------

--
-- Table structure for table `addppl`
--

CREATE TABLE `addppl` (
  `id` int(3) NOT NULL,
  `empid` varchar(4) NOT NULL,
  `empname` varchar(15) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `email` varchar(15) NOT NULL,
  `supadmin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addppl`
--

INSERT INTO `addppl` (`id`, `empid`, `empname`, `phone`, `address`, `email`, `supadmin`) VALUES
(13, 'E001', 'Prakash', '6363664500', 'Punjalakatte', 'pr@gmail.com', 'santhu@gmail.com'),
(14, 'E002', 'Priya', '9423760966', 'Moorje', 'priya546', 'santhu@gmail.com'),
(15, 'E003', 'Sandhya', '8426081256', 'Moorje', 'sandhya675@gmai', 'santhu@gmail.com'),
(16, 'E004', 'Sharvary', '9019426671', 'Punjalakatte', 'sharu@gmail.com', 'santhu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `firstname` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `password`, `firstname`, `email`, `phone`, `address`) VALUES
(1, 'santhu987', 'Santhosh R', 'santhu@gmail.com', '9423760966', 'Bantwala taluk, Punjalakatte');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(3) NOT NULL,
  `img` varchar(200) NOT NULL,
  `supadmin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `img`, `supadmin`) VALUES
(9, 'price.png', 'santhu@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(4) NOT NULL,
  `userid` varchar(4) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(35) NOT NULL,
  `email` varchar(20) NOT NULL,
  `ordered` date NOT NULL,
  `quantity` varchar(5) NOT NULL,
  `recieve` varchar(50) NOT NULL,
  `grind` varchar(50) NOT NULL,
  `pack` varchar(50) NOT NULL,
  `send` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userid`, `name`, `phone`, `address`, `email`, `ordered`, `quantity`, `recieve`, `grind`, `pack`, `send`) VALUES
(1, 'P001', 'Chandru', '7645324587', 'punjalakatte', 'chandru@gmail.com', '2024-04-04', '10', 'Order Placed', 'Grinded State', 'Packing State', 'Delivered'),
(3, 'P002', 'Chaya', '9019426671', 'Punjalakatte', 'chaya@gmail.com', '2024-04-11', '30', 'Order Placed', 'Grinded State', 'Packing State', 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(4) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `phone`, `email`, `password`) VALUES
(6, 'Chandra', '7234981356', 'chandru@gmail.com', 'chandru');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(4) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `ordering` date NOT NULL,
  `message` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `name`, `email`, `ordering`, `message`) VALUES
(2, 'Chandru', 'chandru@gmail.com', '2024-04-09', 'Good');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addppl`
--
ALTER TABLE `addppl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addppl`
--
ALTER TABLE `addppl`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
