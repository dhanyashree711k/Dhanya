$(document).ready(function() {
    $('.action-btn').click(function() {
        var id = $(this).data('id');
        var action = $(this).data('action');
        var buttonText = "";
        switch(action) {
            case "recieve":
                buttonText = "Order Placed";
                break;
            case "grind":
                buttonText = "Grinded State";
                break;
            case "pack":
                buttonText = "Packing State";
                break;
            case "send":
                buttonText = "Delivered";
                break;
            default:
                break;
        }
        
        // Change the button text to the desired text
        $(this).text(buttonText);

        // Send AJAX request to update database if needed
        // Add your AJAX code here to update the database
        // Example:
        /*
        $.ajax({
            url: 'update_order.php',
            type: 'POST',
            data: { id: id, action: action },
            success: function(response) {
                console.log('Order status updated successfully');
            },
            error: function(xhr, status, error) {
                console.error('Error updating order status:', error);
            }
        });
        */
    });
});